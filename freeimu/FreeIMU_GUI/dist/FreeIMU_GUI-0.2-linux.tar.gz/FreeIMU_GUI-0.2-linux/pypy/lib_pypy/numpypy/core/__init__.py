from .fromnumeric import *
from .numeric import *
