from _rpyc_support import proxy_module

proxy_module(globals())
del proxy_module
